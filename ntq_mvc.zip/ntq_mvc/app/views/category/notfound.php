<strong><?php
$mg = isset($errMsg) == false ? "Đường dẫn sai." : $errMsg;
echo $mg;
?></strong>